<?php
return array(
	'jquery' => '>=1.11.3',
	'jquery_migrate' => '>=1.3.0',
	'jquery_ui' => '>=1.10.4',
	'tipsy' => '>=1.0.0',
	'validate' => '^1.14.0',
	'tinymce' => '>=4.1.1',
	'timepicker' => '>=0.3.3',
	'datetimepicker' => '>=1.3.0',
	'multiselect' => '>=1.13.0',
	'chosen' => '>=0.9.8',
	'font_awesome' => '>=4.4.0',
	'pj_bootstrap' => '>=3.3.2',
	'pj_jquery' => '>=1.11.2',
	'pj_validate' => '>=1.10.0',
	'pj_bootstrap_datetimepicker' => '>=4.17.37',
	'pj_perfect_scrollbar' => '>=0.6.11',
	'pj_select2' => '>=4.0.5',
	'storage_polyfill' => '>=1.0.0',
);
?>