START TRANSACTION;

  INSERT INTO `options` (`foreign_id`, `key`, `tab_id`, `value`, `label`, `type`, `order`, `is_visible`, `style`) VALUES
    (1, 'o_bf_include_pickup_address', 4, '1|2|3::2', 'No|Yes|Yes (required)', 'enum', 15, 1, NULL),
    (1, 'o_bf_include_dropoff_address', 4, '1|2|3::2', 'No|Yes|Yes (required)', 'enum', 16, 1, NULL),
    (1, 'o_bf_include_suitcases', 4, '1|2|3::2', 'No|Yes|Yes (required)', 'enum', 17, 1, NULL);

  INSERT INTO `fields` VALUES (NULL, 'opt_o_bf_include_pickup_address', 'backend', 'Options / Pickup address', 'script', NULL);
  SET @id := (SELECT LAST_INSERT_ID());
  INSERT INTO `multi_lang` VALUES (NULL, @id, 'pjField', '::LOCALE::', 'title', 'Pickup address', 'script');

  INSERT INTO `fields` VALUES (NULL, 'opt_o_bf_include_dropoff_address', 'backend', 'Options / Dropoff address', 'script', NULL);
  SET @id := (SELECT LAST_INSERT_ID());
  INSERT INTO `multi_lang` VALUES (NULL, @id, 'pjField', '::LOCALE::', 'title', 'Dropoff address', 'script');

  INSERT INTO `fields` VALUES (NULL, 'opt_o_bf_include_suitcases', 'backend', 'Options / Suitcases', 'script', NULL);
  SET @id := (SELECT LAST_INSERT_ID());
  INSERT INTO `multi_lang` VALUES (NULL, @id, 'pjField', '::LOCALE::', 'title', 'Suitcases', 'script');

  INSERT INTO `fields` VALUES (NULL, 'lblPickupAddress', 'backend', 'Options / Pickup address', 'script', NULL);
  SET @id := (SELECT LAST_INSERT_ID());
  INSERT INTO `multi_lang` VALUES (NULL, @id, 'pjField', '::LOCALE::', 'title', 'Pickup address', 'script');

  INSERT INTO `fields` VALUES (NULL, 'lblDropoffAddress', 'backend', 'Options / Dropoff address', 'script', NULL);
  SET @id := (SELECT LAST_INSERT_ID());
  INSERT INTO `multi_lang` VALUES (NULL, @id, 'pjField', '::LOCALE::', 'title', 'Dropoff address', 'script');

  INSERT INTO `fields` VALUES (NULL, 'lblSuitcases', 'backend', 'Options / Suitcases', 'script', NULL);
  SET @id := (SELECT LAST_INSERT_ID());
  INSERT INTO `multi_lang` VALUES (NULL, @id, 'pjField', '::LOCALE::', 'title', 'Suitcases', 'script');

  SET @id := (SELECT `id` FROM `fields` WHERE `key` = "opt_o_email_confirmation_message_text");
  UPDATE `multi_lang` SET `content` = '<u>Available Tokens:</u><br/><br/>{Title}<br/>{FirstName}<br/>{LastName}<br/>{Email}<br/>{Phone}<br/>{Notes}<br/>{Country}<br/>{City}<br/>{State}<br/>{Zip}<br/>{Address}<br/>{Company}<br/>{PickupAddress}<br>{DropoffAddress}<br>{Suitcases}<br>{Date}<br/>{Time}<br/>{Bus}<br/>{Route}<br/>{Seats}<br/>{TicketTypesPrice}<br/>{UniqueID}<br/>{Total}<br/>{Tax}<br/>{PaymentMethod}<br/>{CCType}<br/>{CCNum}<br/>{CCExp}<br/>{CCSec}<br/>{PrintTickets}<br/>{CancelURL}<br/>' WHERE `foreign_id` = @id AND `model` = "pjField" AND `field` = "title";

  SET @id := (SELECT `id` FROM `fields` WHERE `key` = "opt_o_email_payment_message_text");
  UPDATE `multi_lang` SET `content` = '<u>Available Tokens:</u><br/><br/>{Title}<br/>{FirstName}<br/>{LastName}<br/>{Email}<br/>{Phone}<br/>{Notes}<br/>{Country}<br/>{City}<br/>{State}<br/>{Zip}<br/>{Address}<br/>{Company}<br/>{PickupAddress}<br>{DropoffAddress}<br>{Suitcases}<br>{Date}<br/>{Time}<br/>{Bus}<br/>{Route}<br/>{Seats}<br/>{TicketTypesPrice}<br/>{UniqueID}<br/>{Total}<br/>{Tax}<br/>{PaymentMethod}<br/>{CCType}<br/>{CCNum}<br/>{CCExp}<br/>{CCSec}<br/>{PrintTickets}<br/>{CancelURL}<br/>' WHERE `foreign_id` = @id AND `model` = "pjField" AND `field` = "title";

  SET @id := (SELECT `id` FROM `fields` WHERE `key` = "opt_o_email_cancel_message_text");
  UPDATE `multi_lang` SET `content` = '<u>Available Tokens:</u><br/><br/>{Title}<br/>{FirstName}<br/>{LastName}<br/>{Email}<br/>{Phone}<br/>{Notes}<br/>{Country}<br/>{City}<br/>{State}<br/>{Zip}<br/>{Address}<br/>{Company}<br/>{PickupAddress}<br>{DropoffAddress}<br>{Suitcases}<br>{Date}<br/>{Time}<br/>{Bus}<br/>{Route}<br/>{Seats}<br/>{TicketTypesPrice}<br/>{UniqueID}<br/>{Total}<br/>{Tax}<br/>{PaymentMethod}<br/>{CCType}<br/>{CCNum}<br/>{CCExp}<br/>{CCSec}<br/>{PrintTickets}<br/>{CancelURL}<br/>' WHERE `foreign_id` = @id AND `model` = "pjField" AND `field` = "title";

  SET @id := (SELECT `id` FROM `fields` WHERE `key` = "lblEmailTokens");
  UPDATE `multi_lang` SET `content` = '<u>Available Tokens:</u><br/><br/>{Title}<br/>{FirstName}<br/>{LastName}<br/>{Email}<br/>{Phone}<br/>{Notes}<br/>{Country}<br/>{City}<br/>{State}<br/>{Zip}<br/>{Address}<br/>{Company}<br/>{PickupAddress}<br>{DropoffAddress}<br>{Suitcases}<br>{Date}<br/>{Seat}<br/>{Bus}<br/>{Route}<br/>{Time}<br/>{TicketTypesPrice}<br/>{UniqueID}<br/>{Total}<br/>{Tax}<br/>{PaymentMethod}<br/>{CCType}<br/>{CCNum}<br/>{CCExp}<br/>{CCSec}<br/>{CancelURL}<br/>' WHERE `foreign_id` = @id AND `model` = "pjField" AND `field` = "title";

  SET @id := (SELECT `id` FROM `fields` WHERE `key` = "lblTemplateTokens");
  UPDATE `multi_lang` SET `content` = '<u>Available Tokens:</u>\r\n<br/><br/>\r\n{Title}<br/>\r\n{FirstName}<br/>\r\n{LastName}<br/>\r\n{Email}<br/>\r\n{Phone}<br/>\r\n{Notes}<br/>\r\n{Country}<br/>\r\n{City}<br/>\r\n{State}<br/>\r\n{Zip}<br/>\r\n{Address}<br/>\r\n{Company}<br/>{PickupAddress}<br>{DropoffAddress}<br>{Suitcases}<br>\r\n{Date}<br/>\r\n{Bus}<br/>\r\n{Route}<br/>\r\n{Seat}<br/>\r\n{Time}<br/>\r\n{From_Location}<br/>\r\n{To_Location}<br/>\r\n{Departure_Time}<br/>\r\n{Arrival_Time}<br/>\r\n{TicketType}<br/>\r\n{UniqueID}<br/>\r\n{Total}<br/>{Tax}<br/>\r\n{PaymentMethod}<br/>\r\n{CCType}<br/>\r\n{CCNum}<br/>\r\n{CCExp}<br/>\r\n{CCSec}<br/>\r\n{CancelURL}<br/>' WHERE `foreign_id` = @id AND `model` = "pjField" AND `field` = "title";

  SET @id := (SELECT `id` FROM `fields` WHERE `key` = "opt_o_email_notify_message_text");
  UPDATE `multi_lang` SET `content` = '<u>Available Tokens:</u><br/><br/>{Title}<br/>{FirstName}<br/>{LastName}<br/>{Email}<br/>{Phone}<br/>{Notes}<br/>{Country}<br/>{City}<br/>{State}<br/>{Zip}<br/>{Address}<br/>{Company}<br/>{PickupAddress}<br>{DropoffAddress}<br>{Suitcases}<br>{Date}<br/>{Time}<br/>{Bus}<br/>{Route}<br/>{Seats}<br/>{TicketTypesPrice}<br/>{UniqueID}<br/>{Total}<br/>{Tax}<br/>{PaymentMethod}<br/>{CCType}<br/>{CCNum}<br/>{CCExp}<br/>{CCSec}<br/>{PrintTickets}<br/>{CancelURL}<br/>' WHERE `foreign_id` = @id AND `model` = "pjField" AND `field` = "title";

  ALTER TABLE `bookings`
    ADD `c_pickup_address` VARCHAR(255) NULL AFTER `c_country`,
    ADD `c_dropoff_address` VARCHAR(255) NULL AFTER `c_pickup_address`,
    ADD `c_suitcases` VARCHAR(255) NULL AFTER `c_dropoff_address`;

COMMIT;